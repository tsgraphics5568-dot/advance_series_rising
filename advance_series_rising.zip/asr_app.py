from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime

app = Flask(__name__)

# Home Page
@app.route("/")
def home():
    return render_template("index.html")

# Registration Page
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"]
        game = request.form["game"]
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return render_template("success.html", name=name, game=game, time=now)
    return render_template("register.html")

if __name__ == "__main__":
    app.run(debug=True)
